from flask import Flask, render_template, request, jsonify
import paramiko # para conectar con mikrotik
from librouteros import *
from funciones import *

app = Flask(__name__)

# Función que conecta el mikrotik 
def execute_mikrotik_command(command):
    ssh = paramiko.SSHClient() #crea una instancia de SSHClient
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy()) 
    ssh.connect('192.168.1.69', username='admin', password='admin') #ajusta la IP y el usuario y contraseña de tu mikrotik
    stdin, stdout, stderr = ssh.exec_command(command) #ejecuta el comando en mikrotik
    output = stdout.read().decode() 
    ssh.close() #cierra la conexión
    return output #devuelve el resultado del comando

# Ruta para servir el frontend
@app.route('/')
def index():
    return render_template('index.html')

# La api creará un usuario en mikrotik
@app.route('/create_user', methods=['POST']) 
def create_user():
    data = request.json
    username = data['username']
    password = data['password']
    group = 'full'  # Ajusta esto al grupo que prefieras
    command = f"/user add name={username} password={password} group={group}" #  comando para crear el usuario
    result = execute_mikrotik_command(command)
    return jsonify({"result": result})

# La api agregará una IP a mikrotik
@app.route('/add_ip', methods=['POST'])
def add_ip():
    data = request.json
    ip_address = data['ip']
    interface = "ether1"  #  nombre  de la interfaz, ponla bien no seas menso
    command = f"/ip address add address={ip_address}/24 interface={interface}" # comando para agregar la IP
    result = execute_mikrotik_command(command)
   
    # devuelve un error si no se pudo agregar la IP, sigifica que estas menso
    if "input does not match any value of interface" in result:
        return jsonify({"error": "Interfaz no encontrada en MikroTik. Verifica el nombre de la interfaz."}), 400
    
    return jsonify({"result": result})

# La api configurará el ancho de banda de una IP
@app.route('/set_bandwidth', methods=['POST']) 
def set_bandwidth(): # aquipon bien la info
    data = request.json
    name=data['name']
    target_ip = data['ip'] #pon la informacion bien, si no lo sabes, no le muevas
    max_upload = data['upload']
    max_download = data['download']
    
    command = (f"/queue simple add name={name} target={target_ip} " # comando para configurar el ancho de banda
               f"max-limit={max_upload}k/{max_download}k") #
    result = execute_mikrotik_command(command)
    return jsonify({"result": result})

@app.route('/edit_bandwidth', methods=['POST']) #editar ancho de banda
def edit_bandwidth():
    data = request.json
    target_ip = data['name'] #lo edita por nombre
    max_upload = data['upload']
    max_download = data['download']
    
    editar_ancho_banda(target_ip, max_upload, max_download)
    return jsonify({"result": "Ancho de banda editado correctamente"})

@app.route('/delete_bandwidth', methods=['POST']) #borrar ancho de banda
def delete_bandwidth():
    data = request.json
    target_ip = data['name'] #lo borra por nombre
    
    borrar_ancho_banda(target_ip)
    return jsonify({"result": "Ancho de banda eliminado correctamente"})

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)


function toggleForm(formId) {
    document.querySelectorAll('.form-container').forEach(form => form.style.display = 'none');
    document.getElementById(formId).style.display = 'block';
}

function createUser(event) {
    event.preventDefault();
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    fetch('/create_user', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: username, password: password }),
    })
    .then(response => response.json())
    .then(data => alert('Usuario creado: ' + data.result))
    .catch((error) => console.error('Error:', error));
}

function addIp(event) {
    event.preventDefault();
    const ip = document.getElementById('ip').value;
    const interfaceName = document.getElementById('interface').value;

    fetch('/add_ip', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ip: ip, interface: interfaceName }),
    })
    .then(response => response.json())
    .then(data => alert('IP agregada: ' + data.result))
    .catch((error) => console.error('Error:', error));
}

function setBandwidth(event) {
    event.preventDefault();
    const name = document.getElementById('name').value;
    const ip = document.getElementById('bandwidth_ip').value;
    const upload = document.getElementById('upload').value;
    const download = document.getElementById('download').value;

    fetch('/set_bandwidth', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ip: ip, name: name, upload: upload, download: download }),
    })
    .then(response => response.json())
    .then(data => alert('Ancho de banda configurado: ' + data.result))
    .catch((error) => console.error('Error:', error));
}

function editBandwidth(event) {
    event.preventDefault();
    const name = document.getElementById('name').value;
    const upload = document.getElementById('upload').value;
    const download = document.getElementById('download').value;
    fetch('/edit_bandwidth', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: name, upload: upload, download: download }),
    })
    .then(response => response.json())
    .then(data => alert('Ancho de banda configurado: ' + data.result))
    .catch((error) => console.error('Error:', error));
}

function deleteBandwidth(event) {
    event.preventDefault();
    const name = document.getElementById('name').value;
    fetch('/delete_bandwidth', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: name }),
    })
    .then(response => response.json())
    .then(data => alert('Ancho de banda configurado: ' + data.result))
    .catch((error) => console.error('Error:', error));
}